package Log;

import Page.PAGE;
import Main.extend;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Login extends JFrame{
    public Login(){
        setTitle("车辆租赁系统--管理员登录");
        setSize(450,300);
        new extend().changecoffee(this);
        setLayout(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //获取屏幕大小,让窗口居中显示
        Dimension screenSize =Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(screenSize.width/2-450/2,screenSize.height/2-300/2);
        //设置窗口容器
        Container container1=getContentPane();
        container1.setBackground(Color.WHITE);

        //添加内容
        JLabel laber1=new JLabel("账户:");
        laber1.setFont(new Font("宋体",Font.BOLD,18));
        laber1.setBounds(100,50,80,30);
        JTextField account_text=new JTextField(16);
        account_text.setBounds(150,50,150,30);
        account_text.setFont(new Font("宋体",Font.BOLD,18));
        JLabel laber2=new JLabel("密码:");
        laber2.setFont(new Font("宋体",Font.BOLD,18));
        laber2.setBounds(100,100,80,30);
        JPasswordField passwordField=new JPasswordField(16);
        passwordField.setBounds(150,100,150,30);
        passwordField.setFont(new Font("宋体",Font.BOLD,18));
        container1.add(laber1);
        container1.add(account_text);
        container1.add(laber2);
        container1.add(passwordField);

        JButton log=new JButton("登录");
        log.setBounds(120,180,70,20);
        Font f=new Font("宋体",Font.BOLD,16);
        log.setFont(f);
        JButton reset=new JButton("重置");
        reset.setBounds(230,180,70,20);
        Font f1=new Font("宋体",Font.BOLD,16);
        reset.setFont(f1);
        container1.add(log);
        container1.add(reset);
        //监听登录系统
        log.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            //调用数据库进行查询
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false","root","240443");
                    Statement statement = con.createStatement();
                    ResultSet resultset = statement.executeQuery("select * from admin");
                    int boo=0;
                    while(resultset.next()){
                     String u= resultset.getString("username");
                     String p= resultset.getString("password");
                     String ss=account_text.getText();

                     if(account_text.getText().equals(u) &&passwordField.getText().equals(p)){
                         boo=1;
                         break;
                     }
                    }
                    //如果匹配则登录成功
                    if(boo==1){
                        new PAGE();
                        con.close();
                        setVisible(false);
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "用户不存在或密码错误", "登录失败",JOptionPane.WARNING_MESSAGE);
                        account_text.setText("");
                        passwordField.setText("");
                    }
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        reset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                account_text.setText("");
                passwordField.setText("");
            }
        });
        //添加背景
        new extend().image(this,container1,"src/Image/大桥.png");
        setVisible(true);
    }
}
