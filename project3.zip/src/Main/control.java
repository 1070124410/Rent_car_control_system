package Main;

public interface control {
    default void addCar() {
    }

    default void changeCar() {
    }

    default void removeCar() {
    }
}
