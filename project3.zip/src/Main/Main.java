package Main;

import Log.Login;

public class Main {
    public static void main(String[] args) {
        new Login();
    }

}

