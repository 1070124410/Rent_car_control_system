package Page;

import Main.extend;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.text.DecimalFormat;

public class profit_analyze extends JFrame {
    profit_analyze() throws SQLException {
        setSize(300,200);
        setTitle("利润分析");
        new extend().changecoffee(this);
        setLayout(null);
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        //获取屏幕大小,让窗口居中显示
        Dimension screenSize =Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(screenSize.width/2-450/2,screenSize.height/2-300/2);
        //设置窗口容器
        Container container1=getContentPane();
        container1.setBackground(Color.WHITE);
        //new extend().image(this,container1,"src/Image/蓝天.png");
        double sum=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false","root","240443");
            Statement statement = con.createStatement();
            ResultSet earn = statement.executeQuery("select * from rentcar");
            while(earn.next()){
                String s= earn.getString("Price");
                double d=Double.parseDouble(s);
                sum+=d;
            }
            ResultSet pay = statement.executeQuery("select * from repaircar");
            while(pay.next()){
                    String s1= pay.getString("Price");
                double d1=Double.parseDouble(s1);
                sum-=d1;
            }
            //保留两位小数
            DecimalFormat df = new DecimalFormat("#.00");
            String money=df.format(sum);
            //添加内容
            JLabel laber1=new JLabel(money);
            laber1.setFont(new Font("宋体",Font.BOLD,18));
            laber1.setBounds(160,60,80,30);
            container1.add(laber1);
            JLabel laber2=new JLabel("净利润:");
            laber2.setFont(new Font("宋体",Font.BOLD,18));
            laber2.setBounds(90,60,80,30);
            container1.add(laber2);

            setVisible(true);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
