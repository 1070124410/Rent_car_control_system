package Page;

import Main.control;
import Main.extend;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class repair_information_control extends JFrame implements control {
    //rowData用来存放行数据,columnNames存放列名
    Vector rowData,columnNames;
    //定义数据库需要的全局变量
    PreparedStatement ps=null;
    Connection ct=null;
    ResultSet rs=null;
    public repair_information_control() throws SQLException {
        setTitle("修车信息管理");

        setSize(600,450);
        new extend().changecoffee(this);
        setLayout(null);
        setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
        //获取屏幕大小,让窗口居中显示
        Dimension screenSize =Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(screenSize.width/2-450/2,screenSize.height/2-300/2);
        //设置窗口容器
        Container container1=getContentPane();
        container1.setBackground(Color.WHITE);

        //添加内容
        JLabel l1=new JLabel("车辆信息");
        JLabel l2=new JLabel("信息操作");
        //设置字体和位置
        l1.setFont(new Font("宋体", Font.BOLD, 12));
        l1.setBounds(12,1,80,40);
        l2.setFont(new Font("宋体", Font.BOLD, 12));
        l2.setBounds(400,1,80,40);
        container1.add(l1);
        container1.add(l2);
        //建表
        columnNames=new Vector();
        //设置列名
        columnNames.add("修车编号");
        columnNames.add("修车时间");
        columnNames.add("车辆故障");
        columnNames.add("车辆ID");
        columnNames.add("修车费用");
        rowData=new Vector();
        JTable table=new JTable(rowData,columnNames);
        table.setBounds(10,30,390,360);
        table.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        JScrollPane scrollpane=new JScrollPane(table);
        scrollpane.setBounds(10,30,390,360);
        //连接数据库读取数据
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false","root","240443");
            Statement statement = con.createStatement();
            ResultSet resultset = statement.executeQuery("select * from repaircar");
            while (resultset.next()){
                //rowData可以存放多行
                Vector hang=new Vector();
                hang.add(resultset.getInt(1));
                hang.add(resultset.getString(2));
                hang.add(resultset.getString(3));
                hang.add(resultset.getString(4));
                hang.add(resultset.getInt(5));
                //加入到rowData
                rowData.add(hang);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        container1.add(scrollpane);
        //信息管理
        JButton button1=new JButton("添加");
        Font font=new Font("宋体",Font.BOLD,16);
        button1.setFont(font);
        button1.setBounds(450,80,100,70);
        container1.add(button1);
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new addCar();
                setVisible(false);
            }
        });
        JButton button2=new JButton("修改");
        button2.setFont(font);
        button2.setBounds(450,160,100,70);
        container1.add(button2);
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new changeCar();
                setVisible(false);
            }
        });
        JButton button3=new JButton("删除");
        button3.setFont(font);
        button3.setBounds(450,240,100,70);
        container1.add(button3);
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new removeCar();
                setVisible(false);
            }
        });
        new extend().image(this,container1,"src/Image/动漫.jpg");
        setVisible(true);
    }

    public static class changeCar extends JFrame{
        public changeCar() {
            setTitle("修改信息");
            setSize(450, 300);
            new extend().changecoffee(this);
            setLayout(null);
            setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
            //获取屏幕大小,让窗口居中显示
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            setLocation(screenSize.width / 2 - 450 / 2, screenSize.height / 2 - 300 / 2);
            //设置窗口容器
            Container container = getContentPane();
            container.setBackground(Color.WHITE);
            //添加内容
            JLabel laber0 = new JLabel("修车编号:");
            laber0.setFont(new Font("宋体", Font.BOLD, 18));
            laber0.setBounds(80, 10, 120, 30);
            container.add(laber0);
            JTextField text0 = new JTextField(16);
            text0.setBounds(170, 10, 130, 30);
            text0.setFont(new Font("宋体", Font.BOLD, 18));
            container.add(text0);
            JLabel laber1 = new JLabel("修车时间:");
            laber1.setFont(new Font("宋体", Font.BOLD, 18));
            laber1.setBounds(80, 50, 120, 30);
            container.add(laber1);
            JTextField text1 = new JTextField(16);
            text1.setBounds(170, 50, 130, 30);
            text1.setFont(new Font("宋体", Font.BOLD, 18));
            container.add(text1);
            JLabel laber2 = new JLabel("车辆故障:");
            laber2.setFont(new Font("宋体", Font.BOLD, 18));
            laber2.setBounds(80, 90, 120, 30);
            container.add(laber2);
            JTextField text2 = new JTextField(16);
            text2.setBounds(170, 90, 130, 30);
            text2.setFont(new Font("宋体", Font.BOLD, 18));
            container.add(text2);
            JLabel laber3 = new JLabel("车辆ID:");
            laber3.setFont(new Font("宋体", Font.BOLD, 18));
            laber3.setBounds(98, 130, 120, 30);
            container.add(laber3);
            JTextField text3 = new JTextField(16);
            text3.setBounds(170, 130, 130, 30);
            text3.setFont(new Font("宋体", Font.BOLD, 18));
            container.add(text3);
            JLabel laber4 = new JLabel("修车费用:");
            laber4.setFont(new Font("宋体", Font.BOLD, 18));
            laber4.setBounds(80, 170, 120, 30);
            container.add(laber4);
            JTextField text4 = new JTextField(16);
            text4.setBounds(170, 170, 130, 30);
            text4.setFont(new Font("宋体", Font.BOLD, 18));
            container.add(text4);
            JButton button = new JButton("确认");
            button.setBounds(180, 230, 80, 30);
            Font f = new Font("宋体", Font.BOLD, 16);
            button.setFont(f);
            container.add(button);
            //new extend().image(this,container,"src/Image/动漫.jpg");
            setVisible(true);

            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String sql = "update repaircar set FixDate='" + text1.getText() + "', Question = '"+text2.getText()+"',Price = '"+text3.getText()+"',CarID = '"+text4.getText()+"' where ID='" + text0.getText() + "'";
                    PreparedStatement pstmt;
                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false", "root", "240443");
                        Statement statement = con.createStatement();
                        pstmt = (PreparedStatement) con.prepareStatement(sql);
                        pstmt.executeUpdate();
                        /*pstmt.close();
                        con.close();*/
                        setVisible(false);
                        new repair_information_control();
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                }
            });
        }
    }
    public static class addCar extends JFrame {
        public addCar() {
            setTitle("增加信息");
            setSize(450, 300);
            new extend().changecoffee(this);
            setLayout(null);
            setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
            //获取屏幕大小,让窗口居中显示
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            setLocation(screenSize.width / 2 - 450 / 2, screenSize.height / 2 - 300 / 2);
            //设置窗口容器
            Container container = getContentPane();
            container.setBackground(Color.WHITE);
            //添加内容
            JLabel laber0 = new JLabel("修车编号:");
            laber0.setFont(new Font("宋体", Font.BOLD, 18));
            laber0.setBounds(80, 10, 120, 30);
            container.add(laber0);
            JTextField text0 = new JTextField(16);
            text0.setBounds(170, 10, 130, 30);
            text0.setFont(new Font("宋体", Font.BOLD, 18));
            container.add(text0);
            JLabel laber1 = new JLabel("修车时间:");
            laber1.setFont(new Font("宋体", Font.BOLD, 18));
            laber1.setBounds(80, 50, 120, 30);
            container.add(laber1);
            JTextField text1 = new JTextField(16);
            text1.setBounds(170, 50, 130, 30);
            text1.setFont(new Font("宋体", Font.BOLD, 18));
            container.add(text1);
            JLabel laber2 = new JLabel("车辆故障:");
            laber2.setFont(new Font("宋体", Font.BOLD, 18));
            laber2.setBounds(80, 90, 120, 30);
            container.add(laber2);
            JTextField text2 = new JTextField(16);
            text2.setBounds(170, 90, 130, 30);
            text2.setFont(new Font("宋体", Font.BOLD, 18));
            container.add(text2);
            JLabel laber3 = new JLabel("车辆ID:");
            laber3.setFont(new Font("宋体", Font.BOLD, 18));
            laber3.setBounds(98, 130, 120, 30);
            container.add(laber3);
            JTextField text3 = new JTextField(16);
            text3.setBounds(170, 130, 130, 30);
            text3.setFont(new Font("宋体", Font.BOLD, 18));
            container.add(text3);
            JLabel laber4 = new JLabel("修车费用:");
            laber4.setFont(new Font("宋体", Font.BOLD, 18));
            laber4.setBounds(80, 170, 120, 30);
            container.add(laber4);
            JTextField text4 = new JTextField(16);
            text4.setBounds(170, 170, 130, 30);
            text4.setFont(new Font("宋体", Font.BOLD, 18));
            container.add(text4);
            JButton button = new JButton("确认");
            button.setBounds(180, 230, 80, 30);
            Font f = new Font("宋体", Font.BOLD, 16);
            button.setFont(f);
            container.add(button);
            setVisible(true);

            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String sql = "insert into repaircar (ID,FixDate,Question,Price,CarID) values(?,?,?,?,?)";
                    PreparedStatement pstmt;
                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false", "root", "240443");
                        Statement statement = con.createStatement();
                        pstmt = (PreparedStatement) con.prepareStatement(sql);
                        pstmt.setString(1, text0.getText());
                        pstmt.setString(2, text1.getText());
                        pstmt.setString(3,  text2.getText());
                        pstmt.setString(4,  text3.getText());
                        pstmt.setString(5,  text4.getText());
                        pstmt.executeUpdate();
                        /*pstmt.close();
                        con.close();*/
                        setVisible(false);
                        new repair_information_control();
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                }
            });
        }
    }
    public static class removeCar extends JFrame {
        public removeCar() {
            setTitle("删除信息");
            setSize(300, 200);
            new extend().changecoffee(this);
            setLayout(null);
            setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
            //获取屏幕大小,让窗口居中显示
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            setLocation(screenSize.width / 2 - 450 / 2, screenSize.height / 2 - 300 / 2);
            //设置窗口容器
            Container container = getContentPane();
            container.setBackground(Color.WHITE);
            //添加内容
            JLabel laber = new JLabel("修车编号:");
            laber.setFont(new Font("宋体", Font.BOLD, 18));
            laber.setBounds(40, 20, 90, 30);
            container.add(laber);
            JTextField text = new JTextField(16);
            text.setBounds(130, 20, 90, 30);
            text.setFont(new Font("宋体", Font.BOLD, 18));
            container.add(text);
            JButton button = new JButton("确认");
            button.setBounds(100, 100, 80, 30);
            Font f = new Font("宋体", Font.BOLD, 16);
            button.setFont(f);
            container.add(button);
            setVisible(true);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int i = 0;
                    String sql = "delete from repaircar where ID='" + text.getText() + "'";
                    PreparedStatement pstmt;
                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/data?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false", "root", "240443");
                        Statement statement = con.createStatement();
                        pstmt = (PreparedStatement) con.prepareStatement(sql);
                        pstmt.executeUpdate();
                        /*pstmt.close();
                        con.close();*/
                        setVisible(false);
                        new repair_information_control();
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                }
            });
        }
    }

}
