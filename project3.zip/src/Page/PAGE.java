package Page;

import Main.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class PAGE extends JFrame {
    public  PAGE() {

        setTitle("管理员已登录");
        setSize(650, 500);
        setLayout(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        new extend().changecoffee(this);
        //获取屏幕大小,让窗口居中显示
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(screenSize.width / 2 - 450 / 2, screenSize.height / 2 - 300 / 2);
        //设置窗口容器
        Container container2 = getContentPane();
        container2.setBackground(Color.WHITE);
        //添加标题
        JLabel laber1 = new JLabel("车辆管理系统");
        laber1.setFont(new Font("宋体", Font.BOLD, 24));
        laber1.setBounds(240, 60, 160, 40);
        container2.add(laber1);
        //添加按钮"车辆信息管理"
        JButton button1 = new JButton("车辆信息管理");
        button1.setBounds(120, 120, 150, 60);
        Font f1=new Font("宋体",Font.BOLD,18);
        button1.setFont(f1);
        container2.add(button1);
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new vehicle_information_control();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        });
        //添加按钮"租车信息管理"
        JButton button2 = new JButton("租车信息管理");
        button2.setBounds(360, 120, 150, 60);
        Font f2=new Font("宋体",Font.BOLD,18);
        button2.setFont(f2);
        container2.add(button2);
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new rent_information_control();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        });
        //添加按钮"还车信息管理"
        JButton button3 = new JButton("还车信息管理");
        button3.setBounds(120, 240, 150, 60);
        Font f3=new Font("宋体",Font.BOLD,18);
        button3.setFont(f3);
        container2.add(button3);
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new repay_information_control();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        });
        //添加按钮"修车信息管理"
        JButton button4 = new JButton("修车信息管理");
        button4.setBounds(360, 240, 150, 60);
        Font f4=new Font("宋体",Font.BOLD,18);
        button4.setFont(f4);
        container2.add(button4);
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new repair_information_control();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        });
        //添加按钮"利润分析"
        JButton button5 = new JButton("利润分析");
        button5.setBounds(250, 360, 150, 60);
        Font f5=new Font("宋体",Font.BOLD,18);
        button5.setFont(f5);
        container2.add(button5);
        button5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new profit_analyze();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        });
        //添加背景
        new extend().image(this,container2,"src/Image/蓝天.jpg");

        setVisible(true);
    }

}
